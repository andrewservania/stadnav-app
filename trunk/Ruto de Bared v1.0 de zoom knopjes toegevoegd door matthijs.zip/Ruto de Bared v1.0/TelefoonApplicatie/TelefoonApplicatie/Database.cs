﻿
using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;

namespace TelefoonApplicatie
{
    public class Database : DataContext
    {
        // LET OP!!
        // je moet de database op zo'n manier aanroepen:
        // new Database(@"Data Source=isostore:/BestandsNaam.sdf");
        public Database(String a) : base(a)
        {
        }


        [Table]
        public class Route
        {
            // Define ID: private field, public property, and database column.
            private string _BeschrijvingENG;
            private string _BeschrijvingNL;
            private string _TitelENG;
            private string _TitelNL;


            [Column(IsPrimaryKey = true, IsDbGenerated = true)]
            public int RouteSleutel
            {
                get;
                internal set;
            }

            [Column]
            public String BeschrijvingENG
            {
                get { return _BeschrijvingENG; }
                set { _BeschrijvingENG = value; }
            }

            [Column]
            public String BeschrijvingNL
            {
                get { return _BeschrijvingNL; }
                set { _BeschrijvingNL = value; }
            }

            [Column]
            public String TitelENG
            {
                get { return _TitelENG; }
                set { _TitelENG = value; }
            }

            [Column]
            public String TitelNL
            {
                get { return _TitelNL; }
                set { _TitelNL = value; }
            }
        }
        [Table]
        public class Bezienswaardigheid
        {
            // Define ID: private field, public property, and database column.
            private string _Breedtegraad;
            private string _Lengtegraad;
            private string _BeschrijvingENG;
            private string _BeschrijvingNL;
            private string _TitelENG;
            private string _TitelNL;
            private string _AbeeldingLocatie;


            [Column(IsPrimaryKey = true, IsDbGenerated  = true)]
            public int BezienswaardigheidSleutel
            {
                get ;
                internal set;
            }

            [Column]
            public string Breedtegraad
            {
                get { return _Breedtegraad; }
                set { _Breedtegraad = value; }
            }

            [Column]
            public string Lengtegraad
            {
                get { return _Lengtegraad; }
                set { _Lengtegraad = value; }
            }

            [Column]
            public String BeschrijvingENG
            {
                get { return _BeschrijvingENG; }
                set { _BeschrijvingENG = value; }
            }

            [Column]
            public String BeschrijvingNL
            {
                get { return _BeschrijvingNL; }
                set { _BeschrijvingNL = value; }
            }

            [Column]
            public String TitelENG
            {
                get { return _TitelENG; }
                set { _TitelENG = value; }
            }

            [Column]
            public String TitelNL
            {
                get { return _TitelNL; }
                set { _TitelNL = value; }
            }
            [Column]
            public String AbeeldingLocatie
            {
                get { return _AbeeldingLocatie; }
                set { _AbeeldingLocatie = value; }
            }
        }

        [Table]
        public class Bezienswaardigheid_Route
        {
            private int _BezienswaardigheidSleutel;
            private int _RouteSleutel;
            
            [Column(IsPrimaryKey = true, IsDbGenerated = true)]
            public int koppelsleutel
            {
                get;
                internal set;
            }

            
            [Association(Storage = "sleutel", ThisKey = "koppelsleutel", OtherKey = "RouteSleutel" )]
            private EntityRef<Route> sleutel;
            
            [Association(Storage = "sleutel", ThisKey = "koppelsleutel", OtherKey = "BezienswaardigheidSleutel")]
            private EntityRef<Bezienswaardigheid> sleutel1;
        }
    }
}
