﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Device.Location;
using Microsoft.Phone.Controls.Maps;
using Microsoft.Phone.Controls.Maps.Platform;
using TelefoonApplicatie.geocodeservice;
using System.Windows.Media.Imaging;
using TelefoonApplicatie.Control;
using TelefoonApplicatie.Model;

using Microsoft.Phone.Tasks;
using System.IO.IsolatedStorage;
using System.IO;
using Microsoft.Phone;
using System.Windows.Resources;
using System.Windows.Threading;


namespace TelefoonApplicatie
{
    public partial class MainPage : PhoneApplicationPage
    {
        Navigatie n = new Navigatie();
        Database d;
        Location location = new Location();
        Informatie i = new Informatie();
        RouteLijst rl = new RouteLijst();
        DispatcherTimer t = new DispatcherTimer();

        static List<GeoCoordinate> locaties = new List<GeoCoordinate>();
        // Constructor
        public MainPage()
        {
            test();
            t.Interval = TimeSpan.FromSeconds(1);
            t.Tick += OnTimerTick;
            t.Start();
            locaties.Clear();
            d = new Database(@"Data Source=isostore:/BestandsNaam.sdf");
            InitializeComponent();
            map1.LogoVisibility = Visibility.Collapsed;
            map1.ZoomBarVisibility = Visibility.Visible;
            map1.CopyrightVisibility = Visibility.Collapsed;
            textbox1.Visibility = Visibility.Collapsed;
            textbox1.Tap += textbox1_tap;
        }

        //tick event van de timer
        void OnTimerTick(Object sender, EventArgs args)
        {
            System.Diagnostics.Debug.WriteLine(locaties.Count);
            if (n.routeplanningOpvragen().Count == 0 && locaties.Count > 1)
            {
                n.routePlannen(locaties);
            }
            if (n.getHuidigeLocatie() != null)
            {
                vulLocaties();
            }

            if (locaties.Count > 0)
            {
                
                locatieTekenen();
                routeTekenen();
                locatieZoom();
            }

            
            //afstandcheck
            if (locaties.Count > 1)
            {
                System.Diagnostics.Debug.WriteLine(berekenAfstand());
                //afstand 20 meter
                if (berekenAfstand() < 0.02)
                {
                    foreach (Belangrijkpunt bp in rl.lijstOpvragen())
                    {
                        if (locaties[1].Latitude == bp.locatie.Latitude && locaties[1].Longitude == bp.locatie.Longitude)
                        {
                            i.setHuidigPunt(bp);
                            textbox1.Text = "naam: " + bp.Naam + Environment.NewLine + "latitude: " + bp.locatie + Environment.NewLine + "Cat:" + bp.Categorie;
                            textbox1.Visibility = Visibility.Visible;  
                        }
                    }

                }
            }
        }

        //lijst met bezienswaardigheden vullen
        private void vulLocaties()
        {
            if (rl.lijstOpvragen() != null)
            {
                locaties.Clear();
                if (locaties.Count == 0)
                {
                    if (n.getHuidigeLocatie() != null)
                    {
                        locaties.Add(n.getHuidigeLocatie());
                    }
                }
                foreach (Belangrijkpunt bp in rl.lijstOpvragen())
                {
                    locaties.Add(bp.locatie);
                }
            }
            
        }

        private void test()
        {
            Belangrijkpunt bp = new Belangrijkpunt("Oosterhout", "Hier woont Toby", new GeoCoordinate(51.6410202, 4.8616901), "stad", "imagepath");
            Belangrijkpunt bp2 = new Belangrijkpunt("Breda", "Hier woont Bas", new GeoCoordinate(51.5830700, 4.7769505), "stad", "imagepath2");

            List<Belangrijkpunt> lijstje = new List<Belangrijkpunt>();
            lijstje.Add(bp);
            lijstje.Add(bp2);
            i.routeToevoegen(new Route("stad1", "henk", "sjaak", lijstje));           


            //locaties.Add(new GeoCoordinate(51.6410202, 4.8616901));
            //locaties.Add(new GeoCoordinate(51.5830700, 4.7769505));
        }

        private double berekenAfstand()
        {
            if (locaties.Count > 1)
            {
                return Afstandberekenen.CalcDistance(n.getHuidigeLocatie().Latitude, n.getHuidigeLocatie().Longitude, locaties[1].Latitude, locaties[1].Longitude);
            }
            else
            {
                return 100;
            }
        }

        //zoom op middelpunt
        private void autozoom()
        {
            double lengtegraadgemiddeld = 0;
            double breedtegraadgemiddeld = 0;
            if(locaties != null)
            {
            foreach(Location l in locaties)
            {
                lengtegraadgemiddeld += l.Latitude;
                breedtegraadgemiddeld += l.Longitude;      
            }

            lengtegraadgemiddeld /= locaties.Count();
            breedtegraadgemiddeld /= locaties.Count();

            map1.SetView(new GeoCoordinate(lengtegraadgemiddeld, breedtegraadgemiddeld), 13);
                }
        }

        //zoom op locatie
        private void locatieZoom()
        {
            if (n.getHuidigeLocatie() != null)
            {
                map1.SetView(n.getHuidigeLocatie(), 15);
            }
        }

        //zoom op alle locaties
        private void perfectZoom()
        {
            LocationCollection a = new LocationCollection();
            foreach (Location l in locaties)
            {
                a.Add(l);
            }
            map1.SetView(LocationRect.CreateLocationRect(a));
        }

        private void routeTekenen()
        {
                Color routeColor = Colors.Red;
                SolidColorBrush routeBrush = new SolidColorBrush(routeColor);
                MapPolyline routeLine = new MapPolyline();
                routeLine.Locations = new LocationCollection();
                routeLine.Stroke = routeBrush;
                routeLine.Opacity = 0.50;
                routeLine.StrokeThickness = 5.0;

                List<Location> routelijst = n.routeplanningOpvragen();

                    foreach (Location p in n.routeplanningOpvragen())
                    {
                        routeLine.Locations.Add(new Location { Latitude = p.Latitude, Longitude = p.Longitude });
                    }

                MapLayer myRouteLayer = new MapLayer();
                myRouteLayer.Children.Add(routeLine);
                this.map1.Children.Add(myRouteLayer); 

                int x = 0;

                    foreach (GeoCoordinate gr in locaties)
                    {
                        Pushpin lokatiePushpin = new Pushpin();
                        lokatiePushpin.Template = this.Resources["PinTemplate"] as ControlTemplate;
                        //tapevent toevoegen
                        lokatiePushpin.Tap += locationPushpin_Tap;
                        this.map1.Children.Add(lokatiePushpin);


                            location.Latitude = locaties[x].Latitude;
                            location.Longitude = locaties[x].Longitude;
                            MapLayer.SetPosition(lokatiePushpin, location);
                            //locatie meegeven aan pushpin zelf
                            lokatiePushpin.Location = location;

                            //pushpin naam instellen  miss gebruiken voor pushpin events anders gewoon locatie          

                            foreach (Belangrijkpunt bp in rl.lijstOpvragen())
                            {
                                if (bp.locatie.Latitude == location.Latitude && bp.locatie.Longitude == location.Longitude)
                                {
                                    lokatiePushpin.Name = bp.Naam;
                                }
                            }


                            MapLayer.SetPositionOrigin(lokatiePushpin, PositionOrigin.Center);
                            x++;
                    }
                
        }

        private void locatieTekenen()
        {
            Image image = new Image();
            image.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri("imgPijl.png", UriKind.Relative));
            image.Opacity = 1.0;
            image.RenderTransform = new RotateTransform() { CenterX = n.getHuidigeLocatie().Latitude, CenterY = n.getHuidigeLocatie().Longitude, Angle = n.gethoek()};

            image.Stretch = Stretch.Fill;
            image.Width = 20;
            image.Height = 50;

            MapLayer myLocatieLayer = new MapLayer();
            myLocatieLayer.Children.Add(image);
            this.map1.Children.Add(myLocatieLayer);
        }

        private void BezienswaardigheidBezocht()
        {
            locaties.RemoveAt(1);
        }

        private void textbox1_tap(object sender, GestureEventArgs e)
        {
            textbox1.Visibility = Visibility.Collapsed;
            //afstand 20 meter
            if (berekenAfstand() < 0.02)
            {
                map1.Children.Clear();
                BezienswaardigheidBezocht();
                n.routeplanningVerwijderen();
            }  

            

            NavigationService.Navigate(new Uri("/InformatieScherm.xaml", UriKind.Relative));

        }

        private void locationPushpin_Tap(object sender, GestureEventArgs e)
        {
            Pushpin p = sender as Pushpin;
            textbox1.Text = "naam: " + p.Name + Environment.NewLine + "latitude: " + p.Location.Latitude + Environment.NewLine + "Long:" + p.Location.Longitude ;
            textbox1.Visibility = Visibility.Visible;  
            foreach(Belangrijkpunt bp in rl.lijstOpvragen())
            {
                if(bp.Naam.Equals(p.Name))
                {
                    i.setHuidigPunt(bp);
                }
            }
        }

        private void bitmapFromUri_ImageOpened(object sender, RoutedEventArgs e)
        {
            textbox1.Visibility = Visibility.Visible;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Menuscherm.xaml", UriKind.Relative));
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/HulpScherm.xaml", UriKind.Relative));
        }
    }
}