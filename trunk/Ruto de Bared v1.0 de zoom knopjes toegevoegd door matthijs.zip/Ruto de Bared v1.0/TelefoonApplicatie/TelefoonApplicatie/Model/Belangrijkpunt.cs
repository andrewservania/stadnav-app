﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Device.Location;

namespace TelefoonApplicatie.Model
{
    class Belangrijkpunt
    {
        public String Naam { get; set; }
        public String Info { get; set; }
        public GeoCoordinate locatie { get; set; }
        public String Categorie { get; set; }
        public string imagePath { get; set; }

        //afbeelding

        public Belangrijkpunt(string n, string i, GeoCoordinate l, string c, string p)
        {
            Naam = n;
            Info = i;
            locatie = l;
            Categorie = c;
            imagePath = p;
        }
    }
}
