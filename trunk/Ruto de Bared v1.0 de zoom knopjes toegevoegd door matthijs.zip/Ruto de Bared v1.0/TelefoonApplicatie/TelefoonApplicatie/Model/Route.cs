﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TelefoonApplicatie.Model
{
    class Route
    {
        public String stad { get; set; }
        public String categorie { get; set; }
        public String beoordeling { get; set; }
        List<Belangrijkpunt> BelangrijkePunten = new List<Belangrijkpunt>();

        public Route(string s, string c, string b, List<Belangrijkpunt> bp)
        {
            stad = s;
            categorie = c;
            beoordeling = b;
            BelangrijkePunten = bp;
        }

        public void BelangrijkpuntToevoegen(Belangrijkpunt b)
        {
            BelangrijkePunten.Add(b);
        }

        public List<Belangrijkpunt> getBelangrijkePunten()
        {
            return BelangrijkePunten;
        }
    }
}
