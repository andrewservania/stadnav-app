﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace TelefoonApplicatie
{
    public partial class Page1 : PhoneApplicationPage
    {
        public Page1()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;

            switch(clickedButton.Name)
            {
                case "button1":
                    NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
                    break;
                case "button2":
                    NavigationService.Navigate(new Uri("/Routescherm.xaml", UriKind.Relative));
                    break;
                case "button3":
                    NavigationService.Navigate(new Uri("/HulpScherm.xaml", UriKind.Relative));
                    break;
                case "button4":
                    NavigationService.Navigate(new Uri("/TaalScherm.xaml", UriKind.Relative));
                    break;
            }
        }
    }
}