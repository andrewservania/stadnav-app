﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TelefoonApplicatie.Model;

namespace TelefoonApplicatie.Control
{
    class Informatie
    {
        static List<Route> routes = new List<Route>();
        static Belangrijkpunt huidigPunt = null;

        public Informatie()
        {

        }

        public List<Route> getRoutes()
        {
            return routes;
        }

        public void setHuidigPunt(Belangrijkpunt hp)
        {
            huidigPunt = hp;
        }

        public Belangrijkpunt getHuidigPunt()
        {
            return huidigPunt;
        }

        public String getinfoRoute(Route r)
        {
            
            return "stad: " + r.stad + " - categorie: " + r.categorie + " - beoordeling: "+ r.beoordeling;
        }

        public String getinfoBelangrijkPunt(Belangrijkpunt b)
        {
            return "categorie: " + b.Categorie + " - informatie: "+ b.Info + " - locatie: " + b.locatie + " - naam: " + b.Naam;
        }

        public void routeToevoegen(Route r)
        {
            routes.Add(r);
        }

    }
}
