﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using TelefoonApplicatie.Control;
using TelefoonApplicatie.Model;

namespace TelefoonApplicatie
{
    public partial class Routescherm : PhoneApplicationPage
    {
        Informatie i = new Informatie();
        RouteLijst rl = new RouteLijst();

        public Routescherm()
        {
            InitializeComponent();
            
            lijstVullen();
        }

        private void lijstVullen()
        {
            listBox1.Items.Clear();
            foreach(Route r in i.getRoutes())
            {
                listBox1.Items.Add(r.stad); 
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                foreach (Route r in i.getRoutes())
                {
                    if (r.stad.Equals(listBox1.SelectedItem))
                    {
                        rl.setGeselecteerdeRoute(r.getBelangrijkePunten());
                    }
                }
                NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
            }
            else
            {
                MessageBox.Show("selecteer een route AUB");
            }
        }
    }
}