﻿using System;
using System.Collections.Generic;
using System.Device.Location;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media;
using Microsoft.Phone.Controls.Maps;

namespace TelefoonApplicatie
{
    class HuidigeLocatie
    {
        private GeoCoordinateWatcher watcher = null;
        GeoCoordinate huidigeLocatie;
        GeoCoordinate laatsteLocatie;
        private int hoek;

        public HuidigeLocatie()
        {
            watcher = new GeoCoordinateWatcher(GeoPositionAccuracy.Default);

            watcher.MovementThreshold = 5;
            watcher.PositionChanged += new EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(watcher_PositionChanged);

            watcher.Start();
        }


        private void watcher_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        {
            //if (huidigeLocatie != null)
            //{
            //    laatsteLocatie = huidigeLocatie;
            //}
            huidigeLocatie = e.Position.Location;
            //if (laatsteLocatie != null)
            //{
            //    GeoCoordinate diff = new GeoCoordinate(huidigeLocatie.Latitude - laatsteLocatie.Latitude, huidigeLocatie.Longitude - laatsteLocatie.Longitude);
            //    int rotation = (int)(Math.Atan2(diff.Latitude, diff.Longitude) * 180 / Math.PI);
            //} 

            //wanneer deze regel niet werkt bovenstaande code uncommenten.
            hoek = (int)huidigeLocatie.Course;
            
        }

        public int getHoek()
        {
            return hoek;
        }

        public void setLaatsteLocatie(GeoCoordinate g)
        {
            laatsteLocatie = g;
        }

        public GeoCoordinate getLaatsteLocatie()
        {
            return laatsteLocatie;
        }

        public GeoCoordinate getHuidigeLocatie()
        {
            return huidigeLocatie;
        }

        public string beschikbaar()
        {
            return watcher.Status.ToString();
        }

    }
}
