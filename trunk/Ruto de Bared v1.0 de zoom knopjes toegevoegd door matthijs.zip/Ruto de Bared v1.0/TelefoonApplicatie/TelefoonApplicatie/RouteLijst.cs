﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TelefoonApplicatie.Model;
using TelefoonApplicatie.Control;

namespace TelefoonApplicatie
{
    class RouteLijst
    {
        List <Route> routes = new List<Route>();
        static List<Belangrijkpunt> geselecteerdeRoute = new List<Belangrijkpunt>();

        public RouteLijst()
        {

        }

        public void setGeselecteerdeRoute(List<Belangrijkpunt> l)
        {
            geselecteerdeRoute = l;
        }

        public List<Route> getRoute()
        {
            return routes;
        }

        public List<Belangrijkpunt> lijstOpvragen()
        {
            return geselecteerdeRoute;
        }

    }
}
