﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace TelefoonApplicatie
{
    public partial class Page3 : PhoneApplicationPage
    {
        public Page3()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;

            switch (clickedButton.Name)
            {
                case "engels":
                    NavigationService.Navigate(new Uri("/MenuschermEn.xaml", UriKind.Relative));
                    break;
                case "nederlands":
                    NavigationService.Navigate(new Uri("/Menuscherm.xaml", UriKind.Relative));
                    break;
            }
        }
    }
}