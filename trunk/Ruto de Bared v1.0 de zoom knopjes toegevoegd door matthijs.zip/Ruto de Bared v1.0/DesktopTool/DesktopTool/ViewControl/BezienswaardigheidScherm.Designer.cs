﻿namespace DesktopTool.ViewControl
{
    partial class BezienswaardigheidScherm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.beschrijvingTab = new System.Windows.Forms.TabControl();
            this.beschrijvingTabNL = new System.Windows.Forms.TabPage();
            this.tb_beschrijvingNL = new System.Windows.Forms.RichTextBox();
            this.beschrijvingTabEN = new System.Windows.Forms.TabPage();
            this.tb_beschrijvingEN = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.breedteTextBox = new System.Windows.Forms.TextBox();
            this.lengteTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.titelTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.fotoListBox = new System.Windows.Forms.ListBox();
            this.zoekenButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.verwijderenButton = new System.Windows.Forms.Button();
            this.toevoegenButton = new System.Windows.Forms.Button();
            this.fotoTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.opslaanButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.beschrijvingTab.SuspendLayout();
            this.beschrijvingTabNL.SuspendLayout();
            this.beschrijvingTabEN.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.beschrijvingTab);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.titelTextBox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(225, 320);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Basis Info - Bezienswaardigheid";
            // 
            // beschrijvingTab
            // 
            this.beschrijvingTab.Controls.Add(this.beschrijvingTabNL);
            this.beschrijvingTab.Controls.Add(this.beschrijvingTabEN);
            this.beschrijvingTab.Location = new System.Drawing.Point(7, 194);
            this.beschrijvingTab.Name = "beschrijvingTab";
            this.beschrijvingTab.SelectedIndex = 0;
            this.beschrijvingTab.Size = new System.Drawing.Size(212, 120);
            this.beschrijvingTab.TabIndex = 3;
            // 
            // beschrijvingTabNL
            // 
            this.beschrijvingTabNL.Controls.Add(this.tb_beschrijvingNL);
            this.beschrijvingTabNL.Location = new System.Drawing.Point(4, 22);
            this.beschrijvingTabNL.Name = "beschrijvingTabNL";
            this.beschrijvingTabNL.Padding = new System.Windows.Forms.Padding(3);
            this.beschrijvingTabNL.Size = new System.Drawing.Size(204, 94);
            this.beschrijvingTabNL.TabIndex = 0;
            this.beschrijvingTabNL.Text = "Nederlands";
            this.beschrijvingTabNL.UseVisualStyleBackColor = true;
            // 
            // tb_beschrijvingNL
            // 
            this.tb_beschrijvingNL.Location = new System.Drawing.Point(6, 6);
            this.tb_beschrijvingNL.Name = "tb_beschrijvingNL";
            this.tb_beschrijvingNL.Size = new System.Drawing.Size(192, 85);
            this.tb_beschrijvingNL.TabIndex = 4;
            this.tb_beschrijvingNL.Text = "";
            this.tb_beschrijvingNL.TextChanged += new System.EventHandler(this.tb_beschrijvingNL_TextChanged);
            // 
            // beschrijvingTabEN
            // 
            this.beschrijvingTabEN.Controls.Add(this.tb_beschrijvingEN);
            this.beschrijvingTabEN.Location = new System.Drawing.Point(4, 22);
            this.beschrijvingTabEN.Name = "beschrijvingTabEN";
            this.beschrijvingTabEN.Padding = new System.Windows.Forms.Padding(3);
            this.beschrijvingTabEN.Size = new System.Drawing.Size(204, 94);
            this.beschrijvingTabEN.TabIndex = 1;
            this.beschrijvingTabEN.Text = "Engels";
            this.beschrijvingTabEN.UseVisualStyleBackColor = true;
            // 
            // tb_beschrijvingEN
            // 
            this.tb_beschrijvingEN.Location = new System.Drawing.Point(6, 6);
            this.tb_beschrijvingEN.Name = "tb_beschrijvingEN";
            this.tb_beschrijvingEN.Size = new System.Drawing.Size(192, 85);
            this.tb_beschrijvingEN.TabIndex = 0;
            this.tb_beschrijvingEN.Text = "";
            this.tb_beschrijvingEN.TextChanged += new System.EventHandler(this.tb_beschrijvingEN_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Beschrijving";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.breedteTextBox);
            this.groupBox2.Controls.Add(this.lengteTextBox);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(7, 64);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(212, 106);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Locatie";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Breedtegraad";
            // 
            // breedteTextBox
            // 
            this.breedteTextBox.Location = new System.Drawing.Point(6, 79);
            this.breedteTextBox.Name = "breedteTextBox";
            this.breedteTextBox.Size = new System.Drawing.Size(100, 20);
            this.breedteTextBox.TabIndex = 2;
            this.breedteTextBox.TextChanged += new System.EventHandler(this.breedteTextBox_TextChanged);
            // 
            // lengteTextBox
            // 
            this.lengteTextBox.Location = new System.Drawing.Point(6, 36);
            this.lengteTextBox.Name = "lengteTextBox";
            this.lengteTextBox.Size = new System.Drawing.Size(100, 20);
            this.lengteTextBox.TabIndex = 1;
            this.lengteTextBox.TextChanged += new System.EventHandler(this.lengteTextBox_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Lengtegraad";
            // 
            // titelTextBox
            // 
            this.titelTextBox.Location = new System.Drawing.Point(6, 36);
            this.titelTextBox.Name = "titelTextBox";
            this.titelTextBox.Size = new System.Drawing.Size(213, 20);
            this.titelTextBox.TabIndex = 0;
            this.titelTextBox.TextChanged += new System.EventHandler(this.titelTextBox_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Titel";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.fotoListBox);
            this.groupBox3.Controls.Add(this.zoekenButton);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.verwijderenButton);
            this.groupBox3.Controls.Add(this.toevoegenButton);
            this.groupBox3.Controls.Add(this.fotoTextBox);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(244, 13);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(209, 221);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Extra Info";
            // 
            // fotoListBox
            // 
            this.fotoListBox.FormattingEnabled = true;
            this.fotoListBox.Location = new System.Drawing.Point(91, 105);
            this.fotoListBox.Name = "fotoListBox";
            this.fotoListBox.Size = new System.Drawing.Size(112, 108);
            this.fotoListBox.TabIndex = 10;
            this.fotoListBox.TabStop = false;
            // 
            // zoekenButton
            // 
            this.zoekenButton.Location = new System.Drawing.Point(128, 34);
            this.zoekenButton.Name = "zoekenButton";
            this.zoekenButton.Size = new System.Drawing.Size(75, 23);
            this.zoekenButton.TabIndex = 5;
            this.zoekenButton.Text = "Zoeken";
            this.zoekenButton.UseVisualStyleBackColor = true;
            this.zoekenButton.Click += new System.EventHandler(this.zoekenButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(88, 89);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Foto\'s";
            // 
            // verwijderenButton
            // 
            this.verwijderenButton.Location = new System.Drawing.Point(6, 105);
            this.verwijderenButton.Name = "verwijderenButton";
            this.verwijderenButton.Size = new System.Drawing.Size(79, 23);
            this.verwijderenButton.TabIndex = 7;
            this.verwijderenButton.Text = "Verwijderen";
            this.verwijderenButton.UseVisualStyleBackColor = true;
            this.verwijderenButton.Click += new System.EventHandler(this.verwijderenButton_Click);
            // 
            // toevoegenButton
            // 
            this.toevoegenButton.Location = new System.Drawing.Point(6, 63);
            this.toevoegenButton.Name = "toevoegenButton";
            this.toevoegenButton.Size = new System.Drawing.Size(197, 23);
            this.toevoegenButton.TabIndex = 6;
            this.toevoegenButton.Text = "Toevoegen";
            this.toevoegenButton.UseVisualStyleBackColor = true;
            this.toevoegenButton.Click += new System.EventHandler(this.toevoegenButton_Click);
            // 
            // fotoTextBox
            // 
            this.fotoTextBox.Location = new System.Drawing.Point(6, 36);
            this.fotoTextBox.Name = "fotoTextBox";
            this.fotoTextBox.ReadOnly = true;
            this.fotoTextBox.Size = new System.Drawing.Size(118, 20);
            this.fotoTextBox.TabIndex = 1;
            this.fotoTextBox.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Titel Foto";
            // 
            // opslaanButton
            // 
            this.opslaanButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.opslaanButton.Location = new System.Drawing.Point(244, 240);
            this.opslaanButton.Name = "opslaanButton";
            this.opslaanButton.Size = new System.Drawing.Size(209, 93);
            this.opslaanButton.TabIndex = 8;
            this.opslaanButton.Text = "Opslaan";
            this.opslaanButton.UseVisualStyleBackColor = true;
            this.opslaanButton.Click += new System.EventHandler(this.opslaanButton_Click);
            // 
            // BezienswaardigheidScherm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(465, 345);
            this.ControlBox = false;
            this.Controls.Add(this.opslaanButton);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BezienswaardigheidScherm";
            this.Text = "NieuwWaypoint";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.beschrijvingTab.ResumeLayout(false);
            this.beschrijvingTabNL.ResumeLayout(false);
            this.beschrijvingTabEN.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabControl beschrijvingTab;
        private System.Windows.Forms.TabPage beschrijvingTabNL;
        private System.Windows.Forms.TabPage beschrijvingTabEN;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox breedteTextBox;
        private System.Windows.Forms.TextBox lengteTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox titelTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button verwijderenButton;
        private System.Windows.Forms.Button toevoegenButton;
        private System.Windows.Forms.TextBox fotoTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox tb_beschrijvingNL;
        private System.Windows.Forms.RichTextBox tb_beschrijvingEN;
        private System.Windows.Forms.Button opslaanButton;
        private System.Windows.Forms.Button zoekenButton;
        private System.Windows.Forms.ListBox fotoListBox;
    }
}