﻿using DesktopTool.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesktopTool.ViewControl
{
    public partial class Hoofdscherm : Form
    {
        //TODO helpscherm
        //TODO overscherm
        //TODO bestanden updaten naar telefoon en database aanpassen // applicatie id=05f36914-642d-45e0-8bb9-4e442c513279
        public BezienswaardigheidScherm bezienswaardigheidScherm { get; private set; }
        public RouteScherm routeScherm { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        public Hoofdscherm()
        {
            InitializeComponent();

            bezienswaardigheidScherm = null;
            routeScherm = null;
            Serializer.checkAndCreateFolder(Serializer.SAVE_PATH);
        }

        /// <summary>
        /// Methode om het huidige child-form te verwijderen
        /// </summary>
        private void verwijderActiveChild()
        {
            if (this.ActiveMdiChild != null)
                this.ActiveMdiChild.Dispose();
        }

        /// <summary>
        /// Methode om een form qua grootte en positie aan te passen naar de clientsize
        /// </summary>
        /// <param name="aanTePassenForm"></param>
        private void setFormPositieEnGrootte(Form aanTePassenForm)
        {
            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is MdiClient)
                {
                    aanTePassenForm.Width = ctrl.ClientSize.Width;
                    aanTePassenForm.Height = ctrl.ClientSize.Height;
                    aanTePassenForm.Location = new Point(0, 0);
                    break;
                }
            }
        }

        /// <summary>
        /// Methode om af te handelen wat er gebeurt wanneer een bezienswaardigheid wordt aangemaakt
        /// </summary>
        private void handleNieuweBezienswaardigheidAf()
        {
            if (routeScherm != null && this.ActiveMdiChild == routeScherm)
            {
                routeScherm.zekerVraag();
            }
            else if (bezienswaardigheidScherm != null && this.ActiveMdiChild == bezienswaardigheidScherm)
            {
                bezienswaardigheidScherm.zekerVraag();
            }

            bezienswaardigheidScherm = new BezienswaardigheidScherm();

            bezienswaardigheidScherm.MdiParent = this;

            verwijderActiveChild();
            bezienswaardigheidScherm.Show();
            setFormPositieEnGrootte(bezienswaardigheidScherm); 
        }

        /// <summary>
        /// Methode om af te handelen wat er gebeurt wanneer een bezienswaardigheid wordt geopend
        /// </summary>
        /// <param name="bezienswaardigheid"></param>
        public void handleOpenBezienswaardigheidAf(Bezienswaardigheid bezienswaardigheid)
        {
            if (routeScherm != null && this.ActiveMdiChild == routeScherm)
            {
                routeScherm.zekerVraag();
            }
            else if (bezienswaardigheidScherm != null && this.ActiveMdiChild == bezienswaardigheidScherm)
            {
                bezienswaardigheidScherm.zekerVraag();
            }

            bezienswaardigheidScherm = new BezienswaardigheidScherm(bezienswaardigheid);
            bezienswaardigheidScherm.MdiParent = this;

            verwijderActiveChild();
            bezienswaardigheidScherm.Show();
            setFormPositieEnGrootte(bezienswaardigheidScherm); 
        }

        /// <summary>
        /// Methode om af te handelen wat er gebeurt wanneer een route wordt aangemaakt
        /// </summary>
        public void handleNieuweRouteAf()
        {
            if (bezienswaardigheidScherm != null && this.ActiveMdiChild == bezienswaardigheidScherm)
            {
                bezienswaardigheidScherm.zekerVraag();
            }
            else if (routeScherm != null && this.ActiveMdiChild == routeScherm)
            {
                routeScherm.zekerVraag();
            }

            routeScherm = new RouteScherm();
            routeScherm.MdiParent = this;

            verwijderActiveChild();
            routeScherm.Show();
            setFormPositieEnGrootte(routeScherm);
        }

        /// <summary>
        /// Methode om af te handelen wat er gebeurt wanneer een route wordt geopend
        /// </summary>
        /// <param name="route"></param>
        public void handleOpenRouteAf(Route route)
        {
            if (bezienswaardigheidScherm != null && this.ActiveMdiChild == bezienswaardigheidScherm)
            {
                bezienswaardigheidScherm.zekerVraag();
            }
            else if (routeScherm != null && this.ActiveMdiChild == routeScherm)
            {
                routeScherm.zekerVraag();
            }

            routeScherm = new RouteScherm(route);
            routeScherm.MdiParent = this;

            verwijderActiveChild();
            routeScherm.Show();
            setFormPositieEnGrootte(routeScherm);
        }

        /// <summary>
        /// 
        /// </summary>
        private void handleOpenAf()
        {
            OpenFileDialog openFileDialog;
            openFileDialog = new OpenFileDialog();
            openFileDialog.DefaultExt = "dat";
            openFileDialog.Filter = "data files (*.dat)|*.dat";
            // Display the openFile dialog.

            DialogResult result = openFileDialog.ShowDialog();

            // OK button was pressed. 
            if (result == DialogResult.OK)
            {
                string dataPath = openFileDialog.FileName;

                switch (Path.GetFileName(dataPath))
                {
                    case "bezienswaardigheden.dat":
                        handleBezienswaardigheidLijst(dataPath);
                        break;
                    case "routes.dat":
                        handleRouteLijst(dataPath);
                        break;
                    default:
                        break;
                }

                Invalidate();
            }

            // Cancel button was pressed. 
            else if (result == DialogResult.Cancel)
            {
                return;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataPath"></param>
        private void handleBezienswaardigheidLijst(String dataPath)
        {
            KeuzeMenuOpenen keuzeMenu = new KeuzeMenuOpenen(this, Serializer.DeSerializeObject(dataPath) as List<Bezienswaardigheid>);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataPath"></param>
        private void handleRouteLijst(String dataPath)
        {
            KeuzeMenuOpenen keuzeMenu = new KeuzeMenuOpenen(this, Serializer.DeSerializeObject(dataPath) as List<Route>);
        }
        
        /// <summary>
        /// 
        /// </summary>
        private void handleOpslaanAf()
        {
            if (bezienswaardigheidScherm != null && this.ActiveMdiChild == bezienswaardigheidScherm)
            {
                bezienswaardigheidScherm.opslaan();
            }
            else if (routeScherm != null && this.ActiveMdiChild == routeScherm)
            {
                routeScherm.opslaan();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void handleOverAf()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        private void handleHelpAf()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void waypointToolStripMenuItem_Click(object sender, EventArgs e)
        {
            handleNieuweBezienswaardigheidAf();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void routeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            handleNieuweRouteAf();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            handleOpenAf();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void opslaanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            handleOpslaanAf();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void overToolStripMenuItem_Click(object sender, EventArgs e)
        {
            handleOverAf();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            handleHelpAf();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OpslaanNaarTelefoon(object sender, EventArgs e)
        {
            if (System.IO.Directory.Exists(Serializer.SAVE_PATH))
                //Uploader.ExecuteCommandSync("rs", Serializer.SAVE_PATH);
                //Tijdelijk om te laten zien wat de output is, debugging dus
                MessageBox.Show(Uploader.ExecuteCommandSync("rs", Serializer.SAVE_PATH));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OphalenVanTelefoon(object sender, EventArgs e)
        {
            if (!System.IO.Directory.Exists(Serializer.SAVE_PATH))
                Directory.CreateDirectory(Serializer.SAVE_PATH);

            //Uploader.ExecuteCommandSync("ts", Serializer.SAVE_PATH);
            //Tijdelijk om te laten zien wat de output is, debugging dus
            MessageBox.Show(Uploader.ExecuteCommandSync("ts", Serializer.SAVE_PATH));
        }
    }
}
