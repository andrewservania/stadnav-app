﻿using DesktopTool.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesktopTool.ViewControl
{
    public partial class KeuzeMenuBezienswaardigheidToevoegen : Form
    {
        private RouteScherm routescherm;
        private List<Bezienswaardigheid> bezienwaardigheden;
        private List<Route> routes;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="form"></param>
        /// <param name="bezienwaardigheden"></param>
        public KeuzeMenuBezienswaardigheidToevoegen(RouteScherm form, List<Bezienswaardigheid> bezienwaardigheden)
        {
            InitializeComponent();
            routescherm = form;
            this.bezienwaardigheden = bezienwaardigheden;
            this.routes = null;
            initialListBox();
        }

        /// <summary>
        /// 
        /// </summary>
        private void initialListBox()
        {
            this.Visible = true;

            if (routes != null)
                lb_elementen.DataSource = routes;
            else if (bezienwaardigheden != null)
                lb_elementen.DataSource = bezienwaardigheden;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bt_Ok_Click(object sender, EventArgs e)
        {
            if (bezienwaardigheden != null)
            {
                routescherm.handleVoegnBezienswaardigheidToeAf(lb_elementen.SelectedItem as Bezienswaardigheid);
            }

            this.Close();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bt_cencel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
