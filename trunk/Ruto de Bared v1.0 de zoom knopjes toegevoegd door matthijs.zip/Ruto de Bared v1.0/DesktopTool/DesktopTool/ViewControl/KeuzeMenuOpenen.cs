﻿using DesktopTool.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesktopTool.ViewControl
{
    public partial class KeuzeMenuOpenen : Form
    {
        private Hoofdscherm hoofdscherm;
        private List<Bezienswaardigheid> bezienwaardigheden;
        private List<Route> routes;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="form"></param>
        /// <param name="bezienwaardigheden"></param>
        public KeuzeMenuOpenen(Hoofdscherm form, List<Bezienswaardigheid> bezienwaardigheden)
        {
            InitializeComponent();
            hoofdscherm = form;
            this.bezienwaardigheden = bezienwaardigheden;
            this.routes = null;
            initialListBox();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="form"></param>
        /// <param name="routes"></param>
        public KeuzeMenuOpenen(Hoofdscherm form, List<Route> routes)
        {
            InitializeComponent();
            hoofdscherm = form;
            this.bezienwaardigheden = null;
            this.routes = routes;
            initialListBox();
        }

        /// <summary>
        /// 
        /// </summary>
        private void initialListBox()
        {
            this.Visible = true;

            if (routes != null)
                lb_elementen.DataSource = routes;
            else if (bezienwaardigheden != null)
                lb_elementen.DataSource = bezienwaardigheden;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bt_Ok_Click(object sender, EventArgs e)
        {
            if (routes != null)
            {
                hoofdscherm.handleOpenRouteAf(lb_elementen.SelectedItem as Route);
            }
            else if (bezienwaardigheden != null)
            {
                hoofdscherm.handleOpenBezienswaardigheidAf(lb_elementen.SelectedItem as Bezienswaardigheid);
            }

            this.Close();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bt_cencel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
