﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DesktopTool.Model;
using System.IO;

namespace DesktopTool.ViewControl
{
    public partial class RouteScherm : Form
    {
        public Route huidigeRoute { get; set; }
        public Bezienswaardigheid tmpBezienswaardigheidToevoegen;

        private OpenFileDialog openFileDialog;
        private bool opgeslagen;

        /// <summary>
        /// 
        /// </summary>
        public RouteScherm()
        {
            opgeslagen = false;
            InitializeComponent();

            huidigeRoute = new Route();
            openFileDialog = new OpenFileDialog();

            openFileDialog.DefaultExt = "dat";
            openFileDialog.Filter = "data files (*.dat)|*.dat";
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="route"></param>
        public RouteScherm(Route route)
        {
            opgeslagen = false;
            InitializeComponent();

            huidigeRoute = route;
            openFileDialog = new OpenFileDialog();

            openFileDialog.DefaultExt = "dat";
            openFileDialog.Filter = "data files (*.dat)|*.dat";

            titelTextBox.Text = huidigeRoute.Titel;
            tb_beschrijvingNL.Text = huidigeRoute.BeschrijvingNL;
            tb_beschrijvingEN.Text = huidigeRoute.BeschrijvingEN;
            bezienswaardighedenListBox.DataSource = huidigeRoute.Bezienswaardigheden;
        }

        /// <summary>
        /// Methode om de opslaanButton af te handelen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void opslaanButton_Click(object sender, EventArgs e)
        {
            opslaan();
        }

        /// <summary>
        /// 
        /// </summary>
        public void opslaan()
        {
            //Titel moet ingevuld zijn
            if (titelTextBox.Text != string.Empty)
            {
                huidigeRoute.Titel = titelTextBox.Text;
                huidigeRoute.BeschrijvingNL = tb_beschrijvingNL.Text;
                huidigeRoute.BeschrijvingEN = tb_beschrijvingEN.Text;

                string opslaanPath = Serializer.SAVE_PATH + "routes.dat";
                List<Route> tmpRoutesList;

                // check of bezienswaardigheden.dat al bestaat
                if (File.Exists(opslaanPath))
                {
                    tmpRoutesList = Serializer.DeSerializeObject(opslaanPath) as List<Route>;

                    // check of bestand goede leesbare list van bezienswaardigheden gevonden heeft
                    if (tmpRoutesList != null)
                    {
                        // scant opgehaalde bezienswaardhigehden lijst of deze al een itel met deze titel 
                        // heeft indien dat zo is word deze verwijderd
                        foreach (Route r in tmpRoutesList)
                        {
                            if (r.Titel == huidigeRoute.Titel)
                            {
                                tmpRoutesList.Remove(r);
                                break;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Fout bij lezen van routes.dat", "Fout!",
                            MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                }
                else
                {
                    tmpRoutesList = new List<Route>();
                }

                tmpRoutesList.Add(huidigeRoute);
                opgeslagen = true;

                Serializer.SerializeObject(opslaanPath, tmpRoutesList);

                MessageBox.Show("Gegevens opgeslagen.");
            }
            else
            {
                MessageBox.Show("Vul minimaal een titel voor de route in.", "Fout!",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toevoegenButton_Click(object sender, EventArgs e)
        {
            if (bezienswaardigheidTextBox.Text != string.Empty)
            {
                if (!bezienswaardighedenListBox.Items.Contains(tmpBezienswaardigheidToevoegen))
                {
                    bezienswaardighedenListBox.Items.Add(tmpBezienswaardigheidToevoegen);
                    opgeslagen = false;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void omhoogButton_Click(object sender, EventArgs e)
        {
            int geselecteerdeIndex = bezienswaardighedenListBox.SelectedIndex;
            Bezienswaardigheid geselecteerdeBezienswaardigheid = bezienswaardighedenListBox.SelectedItem
                                                                        as Bezienswaardigheid;
            if (geselecteerdeBezienswaardigheid != null && geselecteerdeIndex > 0)
            {
                bezienswaardighedenListBox.Items.Insert(geselecteerdeIndex - 1, geselecteerdeBezienswaardigheid);
                bezienswaardighedenListBox.Items.RemoveAt(geselecteerdeIndex + 1);
                bezienswaardighedenListBox.SelectedIndex = geselecteerdeIndex - 1;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void omlaagButton_Click(object sender, EventArgs e)
        {
            int geselecteerdeIndex = bezienswaardighedenListBox.SelectedIndex;
            Bezienswaardigheid geselecteerdeBezienswaardigheid = bezienswaardighedenListBox.SelectedItem
                                                                        as Bezienswaardigheid;
            if (geselecteerdeBezienswaardigheid != null && geselecteerdeIndex < bezienswaardighedenListBox.Items.Count - 1)
            {
                bezienswaardighedenListBox.Items.Insert(geselecteerdeIndex + 2, geselecteerdeBezienswaardigheid);
                bezienswaardighedenListBox.Items.RemoveAt(geselecteerdeIndex);
                bezienswaardighedenListBox.SelectedIndex = geselecteerdeIndex + 1;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void verwijderenButton_Click(object sender, EventArgs e)
        {
            bezienswaardighedenListBox.Items.Remove(bezienswaardighedenListBox.SelectedItem);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void zoekenButton_Click(object sender, EventArgs e)
        {
            // Display the openFile dialog.
            DialogResult result = openFileDialog.ShowDialog();

            // OK button was pressed. 
            if (result == DialogResult.OK)
            {
                string dataPath = openFileDialog.FileName;

                switch (Path.GetFileName(dataPath))
                {
                    case "bezienswaardigheden.dat":
                        KeuzeMenuBezienswaardigheidToevoegen keuzeMenu = new KeuzeMenuBezienswaardigheidToevoegen(this,  
                            Serializer.DeSerializeObject(dataPath) as List<Bezienswaardigheid>);
                        break;
                    default:
                        MessageBox.Show("Het geselecteerde bestand moet bezienswaardigheden.dat zijn.", "Fout!",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        break;
                }

                Invalidate();
            }

            // Cancel button was pressed. 
            else if (result == DialogResult.Cancel)
            {
                return;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="bezienswaardigheid"></param>
        public void handleVoegnBezienswaardigheidToeAf(Bezienswaardigheid bezienswaardigheid)
        {
            tmpBezienswaardigheidToevoegen = bezienswaardigheid;
            bezienswaardigheidTextBox.Text = tmpBezienswaardigheidToevoegen.Titel;
        }

        /// <summary>
        /// 
        /// </summary>
        public void zekerVraag()
        {
            if (titelTextBox.Text != string.Empty && !opgeslagen)
            {
                DialogResult dialogResult = MessageBox.Show("Wilt u uw gegeven opslaan?", "Opslaan",
                    MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    opslaan();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void titelTextBox_TextChanged(object sender, EventArgs e)
        {
            opgeslagen = false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tb_beschrijvingNL_TextChanged(object sender, EventArgs e)
        {
            opgeslagen = false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tb_beschrijvingEN_TextChanged(object sender, EventArgs e)
        {
            opgeslagen = false;
        }
    }
}
