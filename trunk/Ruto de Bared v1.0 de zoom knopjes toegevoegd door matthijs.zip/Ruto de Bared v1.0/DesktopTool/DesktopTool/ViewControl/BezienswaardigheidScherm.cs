﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DesktopTool.Model;
using System.Globalization;
using System.IO;

namespace DesktopTool.ViewControl
{
    /// <summary>
    /// 
    /// </summary>
    public partial class BezienswaardigheidScherm : Form
    {
        public Bezienswaardigheid huidigeBezienswaardigheid;

        private OpenFileDialog openFileDialog;
        private bool opgeslagen;

        /// <summary>
        /// 
        /// </summary>
        public BezienswaardigheidScherm()
        {
            opgeslagen = false;
            InitializeComponent();

            huidigeBezienswaardigheid = new Bezienswaardigheid();
            openFileDialog = new OpenFileDialog();

            openFileDialog.DefaultExt = "jpg";
            openFileDialog.Filter = "jpg files (*.jpg)|*.jpg";
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="bezienswaardigheid"></param>
        public BezienswaardigheidScherm(Bezienswaardigheid bezienswaardigheid)
        {
            opgeslagen = false;
            InitializeComponent();

            huidigeBezienswaardigheid = bezienswaardigheid;
            openFileDialog = new OpenFileDialog();

            openFileDialog.DefaultExt = "jpg";
            openFileDialog.Filter = "jpg files (*.jpg)|*.jpg";

            titelTextBox.Text = bezienswaardigheid.Titel;
            lengteTextBox.Text = bezienswaardigheid.locatie.lengtegraad.ToString();
            breedteTextBox.Text = bezienswaardigheid.locatie.breedtegraad.ToString();
            tb_beschrijvingNL.Text = bezienswaardigheid.BeschrijvingNL;
            tb_beschrijvingEN.Text = bezienswaardigheid.BeschrijvingEN;
            fotoListBox.DataSource = bezienswaardigheid.Afbeeldingen;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void opslaanButton_Click(object sender, EventArgs e)
        {
            opslaan();
        }

        /// <summary>
        /// 
        /// </summary>
        public void opslaan()
        {
            if (titelTextBox.Text != string.Empty && lengteTextBox.Text != string.Empty &&
                    breedteTextBox.Text != string.Empty)
            {
                huidigeBezienswaardigheid.Titel = titelTextBox.Text;
                huidigeBezienswaardigheid.BeschrijvingNL = tb_beschrijvingNL.Text;
                huidigeBezienswaardigheid.BeschrijvingEN = tb_beschrijvingEN.Text;
                Locatie locatie = new Locatie();
                locatie.lengtegraad = float.Parse(lengteTextBox.Text);
                locatie.breedtegraad = float.Parse(breedteTextBox.Text);
                huidigeBezienswaardigheid.locatie = locatie;

                foreach (Afbeelding a in fotoListBox.Items)
                {
                    string pathToSaveTo = Serializer.SAVE_PATH + Serializer.AFBEELDINGEN_FOLDER + a.naam;

                    //Als het bestand nog niet in de Afbeeldingen folder staat
                    if (!File.Exists(pathToSaveTo))
                    {
                        File.Copy(a.path, pathToSaveTo);
                    }

                    bool afbeeldingAlInList = false;
                    //Kijk of de afbeelding al in de List staat
                    foreach (Afbeelding afb in huidigeBezienswaardigheid.Afbeeldingen)
                    {
                        if (Path.GetFileName(afb.path) == Path.GetFileName(a.path))
                        {
                            afbeeldingAlInList = true;
                            break;
                        }
                    }
                    //Als de afbeelding nog niet in de list staat
                    if (!afbeeldingAlInList)
                    {
                        huidigeBezienswaardigheid.Afbeeldingen.Add(
                            new Afbeelding(Serializer.AFBEELDINGEN_FOLDER + a.naam));
                    }
                }

                string opslaanPath = Serializer.SAVE_PATH + "bezienswaardigheden.dat";
                List<Bezienswaardigheid> tmpBezienswaardighedenList;

                // check of bezienswaardigheden.dat al bestaat
                if (File.Exists(opslaanPath))
                {
                    tmpBezienswaardighedenList = Serializer.DeSerializeObject(opslaanPath)
                                                    as List<Bezienswaardigheid>;

                    // check of bestand goede leesbare list van bezienswaardigheden gevonden heeft
                    if (tmpBezienswaardighedenList != null)
                    {
                        // scant opgehaalde bezienswaardhigehden lijst of deze al een itel met deze titel 
                        // heeft indien dat zo is word deze verwijderd
                        foreach (Bezienswaardigheid s in tmpBezienswaardighedenList)
                        {
                            if (s.Titel == huidigeBezienswaardigheid.Titel)
                            {
                                tmpBezienswaardighedenList.Remove(s);
                                break;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Fout bij lezen van bezienswaardigheden.dat", "Fout!",
                            MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                }
                else
                {
                    tmpBezienswaardighedenList = new List<Bezienswaardigheid>();
                }

                tmpBezienswaardighedenList.Add(huidigeBezienswaardigheid);
                opgeslagen = true;

                Serializer.SerializeObject(opslaanPath, tmpBezienswaardighedenList);

                MessageBox.Show("Gegevens opgeslagen.");
            }
            else
            {
                MessageBox.Show("Vul minimaal een titel, lengtegraad en breedtegraad voor de bezienswaardigheid in.", 
                    "Fout!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lengteTextBox_TextChanged(object sender, EventArgs e)
        {
            validateInput(lengteTextBox);
            opgeslagen = false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void breedteTextBox_TextChanged(object sender, EventArgs e)
        {
            validateInput(breedteTextBox);
            opgeslagen = false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="box"></param>
        private void validateInput(TextBox box)
        {
            float result;
            if (!float.TryParse(box.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out result))
            {
                box.Clear();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void zoekenButton_Click(object sender, EventArgs e)
        {
            // Display the openFile dialog.
            DialogResult result = openFileDialog.ShowDialog();

            // OK button was pressed. 
            if (result == DialogResult.OK)
            {
                fotoTextBox.Text = openFileDialog.FileName;
                    
                Invalidate();
            }

            // Cancel button was pressed. 
            else if (result == DialogResult.Cancel)
            {
                return;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toevoegenButton_Click(object sender, EventArgs e)
        {
            if (fotoTextBox.Text != string.Empty)
            {
                if (!fotoListBox.Items.Contains(Path.GetFileName(fotoTextBox.Text)))
                {
                    fotoListBox.Items.Add(new Afbeelding(fotoTextBox.Text));
                    opgeslagen = false;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void verwijderenButton_Click(object sender, EventArgs e)
        {
            foreach(Afbeelding a in huidigeBezienswaardigheid.Afbeeldingen)
            {
                Afbeelding geselecteerdeAfbeelding = (Afbeelding)fotoListBox.SelectedItem;
                if(a.naam == geselecteerdeAfbeelding.naam)
                {
                    huidigeBezienswaardigheid.Afbeeldingen.Remove(a);
                    break;
                }
            }
            fotoListBox.Items.Remove(fotoListBox.SelectedItem);

            System.Diagnostics.Debug.WriteLine(fotoListBox.Items.Count + " " + 
                huidigeBezienswaardigheid.Afbeeldingen.Count);
        }

        /// <summary>
        /// 
        /// </summary>
        public void zekerVraag()
        {
            if ((titelTextBox.Text != string.Empty || lengteTextBox.Text != string.Empty ||
                    breedteTextBox.Text != string.Empty) && !opgeslagen)
            {
                DialogResult dialogResult = MessageBox.Show("Wilt u uw gegeven opslaan?", "Opslaan", 
                    MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    opslaan();
                }
            }       
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void titelTextBox_TextChanged(object sender, EventArgs e)
        {
            opgeslagen = false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tb_beschrijvingNL_TextChanged(object sender, EventArgs e)
        {
            opgeslagen = false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tb_beschrijvingEN_TextChanged(object sender, EventArgs e)
        {
            opgeslagen = false;
        }
    }
}
