﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DesktopTool.Model;
using System.Globalization;
using System.IO;

namespace DesktopTool.ViewControl
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public struct Afbeelding
    {
        public Uri path { get; set; }
        public string name { get; set; }

        public Afbeelding(Uri path)
        {
            this.path = path;
            this.name = Path.GetFileName(path.LocalPath);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public partial class BezienswaardigheidScherm : Form
    {
        Bezienswaardigheid huidigeBezienswaardigheid;

        /// <summary>
        /// 
        /// </summary>
        public BezienswaardigheidScherm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void opslaanButton_Click(object sender, EventArgs e)
        {
            if (titelTextBox.Text != string.Empty && lengteTextBox.Text != string.Empty &&
                    breedteTextBox.Text != string.Empty && beschrijvingTabNL.Text != string.Empty &&
                    beschrijvingTabEN.Text != string.Empty)
            {
                huidigeBezienswaardigheid = new Bezienswaardigheid();
                huidigeBezienswaardigheid.Titel = titelTextBox.Text;
                Locatie locatie = new Locatie();
                locatie.lengtegraad = float.Parse(lengteTextBox.Text);
                locatie.breedtegraad = float.Parse(breedteTextBox.Text);
                huidigeBezienswaardigheid.locatie = locatie;

                foreach (Afbeelding a in fotoListBox.Items)
                {
                    Uri uri = new Uri(Serializer.AFBEELDINGEN_FOLDER + Path.GetFileName(a.path.LocalPath));
                    Afbeelding afbeelding = new Afbeelding(uri);

                    if (!File.Exists(Serializer.SAVE_PATH + afbeelding))
                    {
                        File.Copy(a.path.AbsolutePath, Serializer.SAVE_PATH + afbeelding);
                    }

                    if (!huidigeBezienswaardigheid.Afbeeldingen.Contains(afbeelding))
                    {
                        huidigeBezienswaardigheid.Afbeeldingen.Add(afbeelding);
                    }
                }

                //TODO toevoegen foto's
                //foreach(foto)
                // voeg toe aan list

                Serializer.SerializeObject(Serializer.SAVE_PATH + "bezienswaardigheden.dat", huidigeBezienswaardigheid);
            }
            else
            {
                MessageBox.Show("Vul alle velden van de bezienswaardigheid in.", "Fout!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            //indien geopend en aangepast, verwijder oude versie en sla nieuwe op. Anders gewoon toevoegen.
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lengteTextBox_TextChanged(object sender, EventArgs e)
        {
            validateInput(lengteTextBox);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void breedteTextBox_TextChanged(object sender, EventArgs e)
        {
            validateInput(breedteTextBox);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="box"></param>
        private void validateInput(TextBox box)
        {
            float result;
            if (!float.TryParse(box.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out result))
            {
                box.Clear();
            }
        }
    }
}
