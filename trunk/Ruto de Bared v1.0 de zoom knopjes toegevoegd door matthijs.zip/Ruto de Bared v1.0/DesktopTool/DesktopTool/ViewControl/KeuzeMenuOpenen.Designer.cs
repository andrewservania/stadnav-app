﻿namespace DesktopTool.ViewControl
{
    partial class KeuzeMenuOpenen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_elementen = new System.Windows.Forms.ListBox();
            this.bt_Ok = new System.Windows.Forms.Button();
            this.bt_cencel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_elementen
            // 
            this.lb_elementen.FormattingEnabled = true;
            this.lb_elementen.Location = new System.Drawing.Point(9, 10);
            this.lb_elementen.Margin = new System.Windows.Forms.Padding(2);
            this.lb_elementen.Name = "lb_elementen";
            this.lb_elementen.Size = new System.Drawing.Size(194, 160);
            this.lb_elementen.TabIndex = 0;
            // 
            // bt_Ok
            // 
            this.bt_Ok.Location = new System.Drawing.Point(10, 175);
            this.bt_Ok.Margin = new System.Windows.Forms.Padding(2);
            this.bt_Ok.Name = "bt_Ok";
            this.bt_Ok.Size = new System.Drawing.Size(56, 19);
            this.bt_Ok.TabIndex = 1;
            this.bt_Ok.Text = "Ok";
            this.bt_Ok.UseVisualStyleBackColor = true;
            this.bt_Ok.Click += new System.EventHandler(this.bt_Ok_Click);
            // 
            // bt_cencel
            // 
            this.bt_cencel.Location = new System.Drawing.Point(146, 174);
            this.bt_cencel.Margin = new System.Windows.Forms.Padding(2);
            this.bt_cencel.Name = "bt_cencel";
            this.bt_cencel.Size = new System.Drawing.Size(56, 19);
            this.bt_cencel.TabIndex = 1;
            this.bt_cencel.Text = "Sluiten";
            this.bt_cencel.UseVisualStyleBackColor = true;
            this.bt_cencel.Click += new System.EventHandler(this.bt_cencel_Click);
            // 
            // KeuzeMenuOpenen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(212, 207);
            this.Controls.Add(this.bt_cencel);
            this.Controls.Add(this.bt_Ok);
            this.Controls.Add(this.lb_elementen);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "KeuzeMenuOpenen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Open";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lb_elementen;
        private System.Windows.Forms.Button bt_Ok;
        private System.Windows.Forms.Button bt_cencel;
    }
}