﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesktopTool.ViewControl
{
    public partial class UpdateScherm : Form
    {
        /// <summary>
        /// 
        /// </summary>
        public UpdateScherm()
        {
            InitializeComponent();
        }
    }
}
