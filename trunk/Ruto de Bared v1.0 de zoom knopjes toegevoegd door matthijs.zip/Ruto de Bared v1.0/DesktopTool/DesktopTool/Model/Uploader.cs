﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesktopTool.Model
{
    static class Uploader
    {
        private static const string DOELWIT = "de"; //'de' voor telefoon, 'xd' voor emulator
        private static const string PRODUCT_ID = "05f36914-642d-45e0-8bb9-4e442c513279";

        /**
            ISETool.exe ts xd f8ce6878-0aeb-497f-bcf4-65be961d4bba c:\data\myfiles
                  - downloads the isolated store content of application specified by
                    product id from default emulator to c:\data\myfiles folder

            ISETool.exe rs de f8ce6878-0aeb-497f-bcf4-65be961d4bba c:\data\myfiles
                  - uploads all files from c:\data\myfiles on desktop to the isolated
                    store of application specified by product on Windows Phone device

            ISETool.exe rs deviceindex:2 f8ce6878-0aeb-497f-bcf4-65be961d4bba c:\data\myfiles
                  - uploads all files from c:\data\myfiles on desktop to the device
                    specified by device index 2. To get the list of valid indices use
                    the EnumerateDevices command

            ISETool.exe EnumerateDevices
                  - enumerates the list of valid device targets along with their
                    corresponding device index

            ISETool.exe dir:"\My Folder\Images\" deviceindex:2 f8ce6878-0aeb-497f-bcf4-65be961d4bba
                  - lists the contents of "\My Folder\Images\" in device at index 2
        **/
        static public string ExecuteCommandSync(string actie, string path)
        {
            try
            {
                // create the ProcessStartInfo using "cmd" as the program to be run,
                // and "/c " as the parameters.
                // Incidentally, /c tells cmd that we want it to execute the command that follows,
                // and then exit.
                string commando;
                string ISEToolpath = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName
                    + @"\ISETool\ISETool.exe";

                System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo();
                if (path == ";")
                {
                    commando = actie + " " + DOELWIT + " " + PRODUCT_ID;
                    //Tijdelijk voor debugging
                    System.Diagnostics.Debug.WriteLine("--> Ingevoerd commando: " + commando);

                    procStartInfo = new System.Diagnostics.ProcessStartInfo(ISEToolpath, commando);
                }
                else
                {
                    commando = actie + " " + DOELWIT + " " + PRODUCT_ID + " " + path;
                    //Tijdelijk voor debugging
                    System.Diagnostics.Debug.WriteLine("--> Ingevoerd commando: " + commando);

                    procStartInfo = new System.Diagnostics.ProcessStartInfo(ISEToolpath, commando);
                }

                // The following commands are needed to redirect the standard output.
                // This means that it will be redirected to the Process.StandardOutput StreamReader.
                procStartInfo.RedirectStandardOutput = true;
                procStartInfo.UseShellExecute = false;
                // Do not create the black window.
                procStartInfo.CreateNoWindow = true;
                // Now we create a process, assign its ProcessStartInfo and start it
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.StartInfo = procStartInfo;
                proc.Start();
                // Get the output into a string
                string result = proc.StandardOutput.ReadToEnd();
                // Display the command output.
				
                return result;
            }
            catch (Exception objException)
            {
                // Log the exception
                return objException.ToString();
            }
        }
    }
}
