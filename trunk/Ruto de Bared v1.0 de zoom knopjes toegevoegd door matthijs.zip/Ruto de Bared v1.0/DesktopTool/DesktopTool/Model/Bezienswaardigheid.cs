﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesktopTool.Model
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public struct Afbeelding
    {
        public string path { get; set; }
        public string naam { get; set; }

        public Afbeelding(string path) : this()
        {
            this.path = path;
            this.naam = Path.GetFileName(path);
        }

        public override string ToString()
        {
            return naam;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public struct Locatie
    {
        public float lengtegraad { get; set; }
        public float breedtegraad { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public class Bezienswaardigheid
    {
        public string Titel { get; set; }
        public Locatie locatie { get; set; }
        public string BeschrijvingNL { get; set; }
        public string BeschrijvingEN { get; set; }
        public List<Afbeelding> Afbeeldingen { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public Bezienswaardigheid()
        {
            Titel = string.Empty;
            locatie = new Locatie();
            BeschrijvingNL = string.Empty;
            BeschrijvingEN = string.Empty;
            Afbeeldingen = new List<Afbeelding>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return Titel;
        }
    }
}
