﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace DesktopTool.ViewControl
{
    /// <summary>
    /// 
    /// </summary>
    static class Serializer
    {
        public static string SAVE_PATH = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\Desktoptool\";
        public const string AFBEELDINGEN_FOLDER = @"Afbeeldingen\";

        /// <summary>
        /// 
        /// </summary>
        /// <param name="path"></param>
        public static void checkAndCreateFolder(string path)
        {
            if (!System.IO.Directory.Exists(path))
                Directory.CreateDirectory(path + AFBEELDINGEN_FOLDER);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="path"></param>
        /// <param name="objectToSerialize"></param>
        public static void SerializeObject(string path, object objectToSerialize)
        {
            try
            {
                //Open een FileStream die bestanden mag schrijven en aan bestanden mag toevoegen
                FileStream saveStream = new FileStream(path, FileMode.Create, FileAccess.Write);

                using (saveStream)
                {
                    BinaryFormatter bFormatter = new BinaryFormatter();
                    bFormatter.Serialize(saveStream, objectToSerialize);
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static object DeSerializeObject(string path)
        {
            object tmpObject = new object();

            try
            {
                //Open een FileStream die bestanden mag openen en lezen
                FileStream readStream = new FileStream(path, FileMode.Open, FileAccess.Read);
                readStream.Position = 0;

                using (readStream)
                {
                    //Deserializen en dus ophalen die handel!
                    IFormatter readFormatter = new BinaryFormatter();

                    tmpObject = (object)readFormatter.Deserialize(readStream);
                }
            }
            catch (SerializationException)
            {

            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
            }

            return tmpObject;
        }
    }
}
