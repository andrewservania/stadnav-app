﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesktopTool.Model
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public class Route
    {
        public List<Bezienswaardigheid> Bezienswaardigheden { get; set; }
        public string Titel { get; set; }
        public string BeschrijvingNL { get; set; }
        public string BeschrijvingEN { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public Route()
        {
            Bezienswaardigheden = new List<Bezienswaardigheid>();
            Titel = string.Empty;
            BeschrijvingNL = string.Empty;
            BeschrijvingEN = string.Empty;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return Titel;
        }
    }
}
